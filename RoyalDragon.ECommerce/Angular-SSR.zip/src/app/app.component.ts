import { Component } from '@angular/core';
import { SeoService } from 'src/services/seo.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Tour of Heroes';
  constructor(private _seoService:SeoService){   
    this._seoService.createLinkForCanonicalURL();
    this._seoService.createMeta("Test SEO SSR","/assets/img/about.jpg");
  }
}
