Các lệnh để chạy trên nodejs
    yarn build
    ng run angular.io-example:server
    node dist/angular.io-example/server/main.js
